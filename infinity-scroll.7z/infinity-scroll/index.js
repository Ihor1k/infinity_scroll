import {getCards} from './services.js'

const form = document.querySelector('.search-form')

const gallery = document.querySelector('.gallery')
// const loadMore = document.querySelector('.load-more')
const perPage = 20
let page = 1

form.addEventListener('submit', onSubmit)

// loadMore.addEventListener('click', onLoadMore)
document.addEventListener('scroll', throttle(onLoadMore, 400))

async function onLoadMore(){
  if (!(scrollY > document.body.scrollHeight - 1100)) {
    return
  }

  try {
    const query = form.elements.searchQuery.value
    const res = await getCards(query, page, perPage)
    // checkIsOnLoadMoreNeedHide(res.totalHits)
    
    addMarkupGallery(res.hits)
    page += 1
  } catch (e) {
    console.error(e)
  }
}

// function checkIsOnLoadMoreNeedHide(total){
//   if(page*perPage>total){
//     loadMore.style.display = 'none'
//   }
// }

async function onSubmit(e) {
  try {
    e.preventDefault()
    page = 1
    clearMarkup()
    // loadMore.style.display = 'block'
    
    const query = form.elements.searchQuery.value
    const res = await getCards(query, page, perPage)
    // checkIsOnLoadMoreNeedHide(res.totalHits)

    addMarkupGallery(res.hits)

    page += 1
  } catch (e) {
    console.error(e);
  }
}

function addMarkupGallery(images) {
    const markup = images.map(({ webformatURL, largeImageURL, tags, likes, views, comments, downloads }) => `
  <li class="photo-item">
  <a href="${largeImageURL}" class="photo-card">
  <img width="370" height="250" src="${webformatURL}" alt="${tags}" loading="lazy" />
  <div class="info">
    <p class="info-item"><b>Likes </b>${likes}</p>
    <p class="info-item"><b>Views </b>${views}</p>
    <p class="info-item"><b>Comments </b>${comments}</p>
    <p class="info-item"><b>Downloads </b>${downloads}</p>
  </div>
  </a>
  </li>
  `).join('')
  

    gallery.insertAdjacentHTML('beforeend', markup)
}

function clearMarkup() {
    gallery.innerHTML = ''
}

function throttle (callback, limit) {
  var waiting = false;                      
  return function () {                      
      if (!waiting) {                       
          callback.apply(this, arguments);  
          waiting = true;                   
          setTimeout(function () {          
              waiting = false;              
          }, limit);
      }
  }
}
