const BASE_URL = 'https://pixabay.com/api/'
const API_KEY = '45852644-07943f28079f7028b6f1a1e51'
// https://pixabay.com/api/?key=45852644-07943f28079f7028b6f1a1e51&q=cat&image_type=photo&orientation=horizontal&safesearch=true

// export function getImages (query) {
//     return fetch(`${BASE_URL}?key=${API_KEY}&q=${query}&image_type=photo&orientation=horizontal&safesearch=true`)
//     .then(res => res.json())
//     .catch(error => console.log(error))
// }

//! better way
export async function getCards (query, page = 1, perPage) {
    try {
        const response = await fetch(`${BASE_URL}?key=${API_KEY}&q=${query}&image_type=photo&orientation=horizontal&safesearch=true&page=${page}&per_page=${perPage}`) 
        const data = await response.json()
        console.log(data);
        return data
    } catch (e) {
        console.error(e);
    }
}